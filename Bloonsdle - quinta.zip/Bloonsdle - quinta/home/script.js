const gearModal = document.getElementById("gearModal");
const infoModal = document.getElementById("infoModal");

const openModalBtnGear = document.getElementById("openModalBtnGear");
const openModalBtnInfo = document.getElementById("openModalBtnInfo");

const closeModalBtnGear = document.getElementById("closeModalBtnGear");
const closeModalBtnInfo = document.getElementById("closeModalBtnInfo");


openModalBtnGear.onclick = function() {
  gearModal.style.display = "flex";
}


openModalBtnInfo.onclick = function() {
  infoModal.style.display = "flex";
}


closeModalBtnGear.onclick = function() {
  gearModal.style.display = "none";
}

closeModalBtnInfo.onclick = function() {
  infoModal.style.display = "none";
}


window.onclick = function(event) {
  if (event.target === gearModal) {
    gearModal.style.display = "none";
  } else if (event.target === infoModal) {
    infoModal.style.display = "none";
  }
}