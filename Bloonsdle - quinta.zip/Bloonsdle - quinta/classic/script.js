class Suggestions {
    constructor(dataUrl) {
        this.dataUrl = dataUrl;
        this.data = [];
        this.correctMonkey = null;
        this.incorrectAttempts = []; // Array para armazenar tentativas incorretas
        this.init();
    }

    async loadData() {
        try {
            const response = await fetch(this.dataUrl);
            if (!response.ok) {
                throw new Error('Falha ao carregar o JSON: ' + response.statusText);
            }
            this.data = await response.json();
        } catch (error) {
            console.error('Erro ao carregar os dados:', error);
            this.data = [];
        }
    }

    getRandomMonkeyId() {
        const today = new Date();
        const dayOfYear = Math.floor((today - new Date(today.getFullYear(), 0, 0)) / 86400000);
        return (dayOfYear % 24) + 1;
    }

    compareAttributes(selectedMonkey, container) {
        const attributes = ['alcance', 'damage_type', 'class', 'release_version'];

        // Adiciona a comparação ao invés de limpar o conteúdo
        const comparisonDiv = document.createElement('div');
        comparisonDiv.className = 'comparison-item';  // Classe para identificar a comparação

        // Adiciona o quadrado com a imagem do personagem escolhido
        const selectedDiv = document.createElement('div');
        selectedDiv.className = 'character-selected';
        selectedDiv.style.display = 'flex';
        selectedDiv.style.flexDirection = 'row';
        selectedDiv.style.alignItems = 'center';

        const img = document.createElement('img');
        img.src = selectedMonkey.image;
        img.alt = selectedMonkey.name;
        img.style.width = '50px';
        img.style.height = '50px';
        img.style.marginRight = '10px'; // Espaço entre a imagem e os atributos

        const nameSpan = document.createElement('span');
        nameSpan.textContent = selectedMonkey.name;

        selectedDiv.appendChild(img);
        selectedDiv.appendChild(nameSpan);
        comparisonDiv.appendChild(selectedDiv); // Adiciona o quadrado com a foto do personagem

        // Adiciona os quadrados para comparação de atributos
        const correctMonkey = this.correctMonkey; // A comparação é com o "macaco correto"
        attributes.forEach(attr => {
            const resultDiv = document.createElement('div');
            resultDiv.className = 'attribute-square';
            resultDiv.style.display = 'flex';
            resultDiv.style.alignItems = 'center';
            resultDiv.style.justifyContent = 'center';
            resultDiv.style.marginRight = '10px'; // Espaço entre os quadrados

            const attributeLabel = document.createElement('span');
            attributeLabel.textContent = `${attr.charAt(0).toUpperCase() + attr.slice(1)}:`;

            const userValue = selectedMonkey[attr];
            const correctValue = correctMonkey[attr];

            const valueSpan = document.createElement('span');
            valueSpan.textContent = `${userValue}`;
            valueSpan.style.padding = '5px';
            valueSpan.style.textAlign = 'center';

            if (userValue === correctValue) {
                valueSpan.style.backgroundColor = 'green';
            } else {
                valueSpan.style.backgroundColor = 'red';
            }

            resultDiv.appendChild(valueSpan);
            comparisonDiv.appendChild(resultDiv);  // Adiciona o quadrado do atributo
        });

        container.appendChild(comparisonDiv); // Adiciona a nova comparação ao contêiner
    }

    selectMonkey(item) {
        const searchInput = document.getElementById('search');
        searchInput.value = item.name;
        this.displayResults([]); // Limpa os resultados anteriores
        this.compareAttributes(item, document.getElementById('resultComparison')); // Compara o macaco selecionado
    }

    displayIncorrectAttempts() {
        const attemptsContainer = document.getElementById('incorrectAttempts');
        if (!attemptsContainer) {
            console.error('Contêiner de tentativas incorretas não encontrado!');
            return;
        }

        // Limpa as tentativas anteriores
        attemptsContainer.innerHTML = '';

        // Exibe as tentativas incorretas como "quadrados"
        this.incorrectAttempts.forEach(attempt => {
            const attemptDiv = document.createElement('div');
            attemptDiv.className = 'incorrect-attempt'; // Classe para o "quadrado" da tentativa
            attemptDiv.style.display = 'flex';
            attemptDiv.style.marginBottom = '10px';
            attemptDiv.style.flexWrap = 'wrap'; // Permite que os quadrados se ajustem em várias linhas se necessário

            // Adiciona a foto do macaco
            const img = document.createElement('img');
            img.src = attempt.image;
            img.alt = attempt.name;
            img.style.width = '80px';
            img.style.height = '80px';
            img.style.marginRight = '15px'; // Espaço entre a foto e os atributos

            attemptDiv.appendChild(img);

            // Adiciona os atributos do macaco em quadrados
            const attributes = ['alcance', 'damage_type', 'class', 'release_version'];

            attributes.forEach(attr => {
                const attributeDiv = document.createElement('div');
                attributeDiv.className = 'attribute-square';
                attributeDiv.style.display = 'flex';
                attributeDiv.style.alignItems = 'center';
                attributeDiv.style.justifyContent = 'center';
                attributeDiv.style.marginRight = '15px'; // Espaço entre os quadrados

                const valueSpan = document.createElement('span');
                valueSpan.textContent = attempt[attr];
                valueSpan.style.padding = '5px';
                valueSpan.style.textAlign = 'center';
                valueSpan.style.backgroundColor = 'lightgray'; // Cor de fundo para atributos

                attributeDiv.appendChild(valueSpan);
                attemptDiv.appendChild(attributeDiv);
            });

            attemptsContainer.appendChild(attemptDiv);
        });
    }

    displayResults(results) {
        const resultsContainer = document.getElementById('result');
        resultsContainer.innerHTML = '';
        resultsContainer.style.display = 'none';  // Remover a exibição da lista de resultados

        // Não adicionamos nada à lista de resultados para garantir que ela não seja exibida
    }

    filterData(query) {
        return this.data.filter(item => item.name.toLowerCase().includes(query.toLowerCase()));
    }

    init() {
        this.loadData().then(() => {
            const randomMonkeyId = this.getRandomMonkeyId();
            this.correctMonkey = this.data[randomMonkeyId - 1];

            const searchInput = document.getElementById('search');
            const feedback = document.getElementById('feedback');
            const result = document.getElementById('result');
            const resultComparison = document.getElementById('resultComparison');
            const attemptsContainer = document.getElementById('incorrectAttempts');

            feedback.style.display = 'none';
            result.style.display = 'none';
            resultComparison.style.display = 'none';
            attemptsContainer.style.display = 'none'; // Inicialmente oculto

            searchInput.addEventListener('input', () => {
                const query = searchInput.value;
                const filteredData = this.filterData(query);
                this.displaySuggestions(filteredData);
            });

            document.getElementById('submitButton').addEventListener('click', (event) => {
                event.preventDefault();  // Previne o envio do formulário

                const selectedMonkeyName = searchInput.value.trim();

                if (!selectedMonkeyName) {
                    alert('Por favor, digite o nome de um macaco!');
                    return;
                }

                const selectedMonkey = this.filterData(selectedMonkeyName)[0];

                if (!selectedMonkey) {
                    alert('Macaco não encontrado!');
                    return;
                }

                // Verifica se a tentativa já foi feita
                if (this.incorrectAttempts.some(attempt => attempt.id === selectedMonkey.id)) {
                    feedback.innerHTML = "<p style='color: orange;'>Você já tentou esse macaco. Tente outro!</p>";
                    feedback.style.display = 'flex';
                    return;
                }

                // Adiciona a tentativa incorreta caso não tenha sido bem-sucedida
                const correct = selectedMonkey.id === this.correctMonkey.id;
                if (correct) {
                    feedback.innerHTML = "<p style='color: green;'>Parabéns! Você acertou o macaco correto!</p>";
                    attemptsContainer.style.display = 'none'; // Esconde as tentativas após acerto
                } else {
                    feedback.innerHTML = "<p style='color: red;'>Tentativa incorreta. Tente novamente!</p>";
                    this.incorrectAttempts.push(selectedMonkey); // Adiciona a tentativa incorreta
                    this.displayIncorrectAttempts();  // Exibe as tentativas incorretas
                    attemptsContainer.style.display = 'block'; // Exibe o contêiner das tentativas incorretas
                }

                feedback.style.display = 'flex';
                result.style.display = 'none';

                // Limpar a área de comparação antes de mostrar a próxima tentativa
                this.compareAttributes(selectedMonkey, resultComparison);
            });
        });
    }

    displaySuggestions(suggestions) {
        const suggestionsContainer = document.getElementById('suggestionsContainer');
        suggestionsContainer.innerHTML = '';
        if (suggestions.length === 0) {
            suggestionsContainer.style.display = 'none';
            return;
        }

        suggestionsContainer.style.display = 'block';

        suggestions.forEach(item => {
            const suggestionItem = document.createElement('div');
            suggestionItem.className = 'suggestion-item';
            suggestionItem.style.padding = '8px';
            suggestionItem.style.borderBottom = '1px solid #ccc';

            const img = document.createElement('img');
            img.src = item.image || '';  // Garantir que a imagem exista
            img.alt = item.name || 'Imagem não disponível';
            img.style.width = '40px';

            const name = document.createElement('span');
            name.textContent = item.name;

            suggestionItem.appendChild(img);
            suggestionItem.appendChild(name);
            suggestionsContainer.appendChild(suggestionItem);

            suggestionItem.addEventListener('click', () => {
                this.selectMonkey(item);
                suggestionsContainer.style.display = 'none';
            });
        });
    }
}

// Inicializa a classe com o caminho do JSON
new Suggestions('monkeys.json');
