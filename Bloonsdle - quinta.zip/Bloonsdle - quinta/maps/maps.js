let maxAttempts = 5;
let currentAttempts = maxAttempts;
let guesses = [];

const blurLevels = [
    'blur(12px)', 
    'blur(8px)',
    'blur(6px)',
    'blur(5px)',
    'blur(3px)',
    'blur(1px)',
];

const characters = {
    '1.jpg': 'Monkey Meadow',
    '2.jpg': 'In The Loop',
    '3.jpg': 'Middle Of The Road',
    '4.jpg': 'Adoras Temple',
    '5.jpg': 'Alpine Run',
    '6.jpg': 'Another Brick',
    '7.jpg': 'Balance',
    '8.jpg': 'Bazaar',
    '9.jpg': 'Bloody Puddles',
    '10.jpg': 'Bloonarius Prime',
    '11.jpg': 'Candy Falls',
    '12.jpg': 'Cargo',
    '13.jpg': 'Carved',
    '14.jpg': 'Castle Revange',
    '15.jpg': 'Chutes',
    '16.jpg': 'Cornfield',
    '17.jpg': 'Covered Garden',
    '18.jpg': 'Cracked',
    '19.jpg': 'Cubism',
    '20.jpg': 'Dark Castle',
    '21.jpg': 'Dark Dungeons',
    '22.jpg': 'Dark Path',
    '23.jpg': 'Downstream',
    '24.jpg': 'End Of The Road',
    '25.jpg': 'Erosion',
    '26.jpg': 'Firing Range',
    '27.jpg': 'Flooded Valley',
    '28.jpg': 'Four Circles',
    '29.jpg': 'Frozen Over',
    '30.jpg': 'Geared',
    '31.jpg': 'Glacial Trail',
    '32.jpg': 'Haunted',
    '33.jpg': 'Hedge',
    '34.jpg': 'High Finance',
    '35.jpg': 'Infernal',
    '36.jpg': 'Karts and Darts',
    '37.jpg': 'Logs',
    '38.jpg': 'Lotus Island',
    '39.jpg': 'Luminous Cove',
    '40.jpg': 'Mesa',
    '41.jpg': 'Midnight Mansion',
    '42.jpg': 'Moon Landing',
    '43.jpg': 'Muddy Puddles',
    '44.jpg': 'Off The Coast',
    '45.jpg': 'One Two Tree',
    '46.jpg': '#Ouch',
    '47.jpg': 'Pats Pond',
    '48.jpg': 'Peninsula',
    '49.jpg': 'Polyphemus',
    '50.jpg': 'Quad',
    '51.jpg': 'Quarry',
    '52.jpg': 'Quiet Street',
    '53.jpg': 'Rake',
    '54.jpg': 'Ravine',
    '55.jpg': 'Resort',
    '56.jpg': 'Sanctuary',
    '57.jpg': 'Scrapyard',
    '58.jpg': 'Spice Islands',
    '59.jpg': 'Spillway',
    '60.jpg': 'Spring Spring',
    '61.jpg': 'Streambed',
    '62.jpg': 'Sulfur Springs',
    '63.jpg': 'Sunken Columns',
    '64.jpg': 'The Cabin',
    '65.jpg': 'Tinkerton',
    '66.jpg': 'Town Center',
    '67.jpg': 'Tree Stump',
    '68.jpg': 'Underground',
    '69.jpg': 'Water Park',
    '70.jpg': 'Winter Park'


    
};            

let currentImage = '';
let correctAnswer = '';
let initialRotation = Math.random() * 360;

function getImageForToday() {
    const totalImages = Object.keys(characters).length;
    const today = new Date();
    const dayOfYear = Math.floor((today - new Date(today.getFullYear(), 0, 0)) / 86400000);
    const imageIndex = (dayOfYear % totalImages) + 1;
    const imageName = `${imageIndex}.jpg`;
    currentImage = imageName;
    correctAnswer = characters[imageName];
    return `imgs-maps/${imageName}`;
}


function celebrateVictory() {
    confetti({
        particleCount: 100,
        spread: 160,
        origin: { y: 0.6 }
    });
}

function submitGuess() {
    const input = document.getElementById('guess-input').value.trim();
    const resultElement = document.getElementById('result');
    const attemptCountElement = document.getElementById('attempt-count');
    const imageElement = document.getElementById('character-image');
    const suggestionsContainer = document.getElementById('suggestions');

    if (!imageElement) {
        console.error('Elemento com ID "character-image" não encontrado.');
        return;
    }

    if (guesses.includes(input.toLowerCase())) {
        resultElement.textContent = 'Você já tentou esse palpite. Tente outro!';
        return;
    }

    guesses.push(input.toLowerCase());

    if (input === '') {
        resultElement.textContent = 'Por favor, digite um palpite.';
        return;
    }

    if (input.toLowerCase() === correctAnswer.toLowerCase()) {
        
        resultElement.textContent = 'Parabéns! Você acertou!';
        celebrateVictory();  // 
        suggestionsContainer.innerHTML = '';
        document.getElementById('guess-input').value = '';
        imageElement.style.filter = 'blur(0) grayscale(0)';
        imageElement.style.transform = 'rotate(0deg)';
    } else {
        
        if (currentAttempts > 0) {
            currentAttempts--;
            attemptCountElement.textContent = currentAttempts;

            const blurIndex = maxAttempts - currentAttempts;
            imageElement.style.filter = blurLevels[blurIndex] + ' grayscale(100%)';

            rotateImage();

            if (currentAttempts <= 0) {
                resultElement.textContent = `Você perdeu! A resposta era "${correctAnswer}".`;
                
                imageElement.style.filter = 'blur(0) grayscale(0)';
                imageElement.style.transform = 'rotate(0deg)'; 
            } else {
                resultElement.textContent = 'Resposta errada. Tente novamente!';
            }
        }
    }

    
    document.getElementById('guess-input').value = '';
}

function filterCharacters(input) {
    return Object.values(characters).filter(character => 
        character.toUpperCase().includes(input.toUpperCase())
    );
}

function displaySuggestions(suggestions) {
    const suggestionsContainer = document.getElementById('suggestions');
    suggestionsContainer.innerHTML = ''; 

    if (suggestions.length === 0) {
        return;
    }

    suggestions.forEach(character => {
        const characterImage = Object.keys(characters).find(key => characters[key] === character);
        const suggestionItem = document.createElement('li');
        suggestionItem.style.cursor = 'pointer';

        // Cria a imagem
        const img = document.createElement('img');
        img.src = `imgs-maps/${characterImage}`; // Adapte o caminho se necessário
        img.alt = character;
        img.style.width = '50px'; // Ajuste o tamanho da imagem
        img.style.height = '50px';
        img.style.marginRight = '30px'; // Espaçamento entre a imagem e o texto

        suggestionItem.appendChild(img); // Adiciona a imagem ao item
        suggestionItem.appendChild(document.createTextNode(character)); // Adiciona o texto

        suggestionItem.className = 'suggestions';
        suggestionItem.addEventListener('click', () => {
            const input = document.getElementById('guess-input');
            input.value = character;
            suggestionsContainer.innerHTML = ''; // Limpa sugestões ao clicar
        });
        suggestionsContainer.appendChild(suggestionItem);
    });
}

document.getElementById('guess-input').addEventListener('input', function() {
    const input = this.value.trim(); // Obtém o valor do input e remove espaços
    if (input === '') {
        // Se o campo estiver vazio, limpa as sugestões
        document.getElementById('suggestions').innerHTML = '';
        return; // Não filtra sugestões
    }
    const suggestions = filterCharacters(input); // Filtra os personagens
    displaySuggestions(suggestions); // Exibe as sugestões
});

document.addEventListener('DOMContentLoaded', function () {
    const imageElement = document.getElementById('character-image');
    const imageSrc = getImageForToday();
    
    if (imageElement) {
        imageElement.src = imageSrc;
        imageElement.style.filter = 'blur(12px) grayscale(100%)';
    } else {
        console.error('Elemento com ID "character-image" não encontrado.');
    }

    // A função submitGuess já está definida no seu código // By Leozin capota barca

document.getElementById('guess-input').addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {  // Verifica se a tecla pressionada é o Enter
        event.preventDefault();   // Evita o comportamento padrão de envio de formulário (caso tenha algum)
        submitGuess();            // Chama a função de envio
    }
});

document.getElementById('guess-input').addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {  // Verifica se a tecla pressionada é o Enter
        event.preventDefault();   // Evita o comportamento padrão de envio de formulário (caso tenha algum)
        submitGuess();            // Chama a função de envio
    }
});

});
